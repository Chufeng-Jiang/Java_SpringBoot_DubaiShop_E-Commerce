package com.dushop.common.entity;

/*
 *@BelongsProject: DuShopProject
 *@BelongsPackage: com.dushop.common.entity
 *@Author: Jiang Chufeng
 *@CreateTime: 2022-08-23  13:10
 *@Description: TODO
 *@Version: 1.0
 */

public enum AuthenticationType {
    DATABASE, FACEBOOK, GOOGLE
}