package com.dushop.common.entity.dubaishop_setting;
/*
 *@BelongsProject: DuShopProject
 *@BelongsPackage: com.dushop.common.entity
 *@Author: Jiang Chufeng
 *@CreateTime: 2022-08-13  19:17
 *@Description: TODO
 *@Version: 1.0
 */

public enum SettingCategory {
    GENERAL, MAIL_SERVER, MAIL_TEMPLATES, CURRENCY, PAYMENT
}