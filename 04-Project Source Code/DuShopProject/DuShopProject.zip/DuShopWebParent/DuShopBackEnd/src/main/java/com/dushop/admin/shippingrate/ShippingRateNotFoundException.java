package com.dushop.admin.shippingrate;
/*
 *@BelongsProject: DuShopProject
 *@BelongsPackage: com.dushop.admin.shippingrate
 *@Author: Jiang Chufeng
 *@CreateTime: 2022-08-25  17:39
 *@Description: TODO
 *@Version: 1.0
 */

public class ShippingRateNotFoundException extends Exception {

    public ShippingRateNotFoundException(String message) {
        super(message);
    }

}