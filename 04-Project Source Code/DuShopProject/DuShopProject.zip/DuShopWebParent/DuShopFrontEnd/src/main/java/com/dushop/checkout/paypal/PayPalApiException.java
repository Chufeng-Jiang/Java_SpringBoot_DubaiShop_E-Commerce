package com.dushop.checkout.paypal;
/*
 *@BelongsProject: DuShopProject
 *@BelongsPackage: com.dushop.checkout.paypal
 *@Author: Jiang Chufeng
 *@CreateTime: 2022-08-28  22:57
 *@Description: TODO
 *@Version: 1.0
 */

public class PayPalApiException extends Exception {

    public PayPalApiException(String message) {
        super(message);
    }

}