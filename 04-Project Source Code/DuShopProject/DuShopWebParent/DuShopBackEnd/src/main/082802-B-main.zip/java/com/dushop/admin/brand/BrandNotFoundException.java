package com.dushop.admin.brand;
/*
 *@BelongsProject: DuShopProject
 *@BelongsPackage: com.dushop.admin.brand
 *@Author: Jiang Chufeng
 *@CreateTime: 2022-08-04  20:22
 *@Description: TODO
 *@Version: 1.0
 */

public class BrandNotFoundException extends Exception {
    public BrandNotFoundException(String message) {
        super(message);
    }

}