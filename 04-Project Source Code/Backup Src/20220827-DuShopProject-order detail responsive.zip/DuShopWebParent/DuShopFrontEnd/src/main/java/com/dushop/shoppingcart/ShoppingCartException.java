package com.dushop.shoppingcart;
/*
 *@BelongsProject: DuShopProject
 *@BelongsPackage: com.dushop.shoppingcart
 *@Author: Jiang Chufeng
 *@CreateTime: 2022-08-24  23:20
 *@Description: TODO
 *@Version: 1.0
 */

public class ShoppingCartException extends Exception {

    public ShoppingCartException(String message) {
        super(message);
    }

}